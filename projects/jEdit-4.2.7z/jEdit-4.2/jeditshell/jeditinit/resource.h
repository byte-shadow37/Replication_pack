//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by jeditinit.rc
//
#define IDP_OLE_INIT_FAILED             100
#define IDS_ABOUTBOX                    101
#define IDM_ABOUTBOX                    101
#define IDI_JEDIT                       101
#define IDD_JEDITINIT_DIALOG            102
#define IDS_FILTER_JAVA_EXEC            102
#define IDS_FILTER_JEDIT_TARGET         103
#define IDS_ERR_CAPTION                 104
#define IDS_ERR_EMPTY_EXEC              105
#define IDS_ERR_NOFILE                  106
#define IDS_ERR_BADEXEC                 107
#define IDS_ERR_BADJAR                  108
#define IDS_ERR_BADDIR                  109
#define IDS_MSG_RESTART                 110
#define IDS_MSG_INSTALLQUERY            111
#define IDS_ERR_NEEDINSTALL             112
#define IDS_MSG_SEARCHQUERY             113
#define IDS_ERR_COM_FAILURE             114
#define IDS_MSG_NEXTTIME                115
#define IDS_MSG_CONFIRM_NOSERVER        116
#define IDS_ERR_JAVA_NOT_FOUND          117
#define IDS_COMBO_1                     201
#define IDS_COMBO_2                     202
#define IDS_COMBO_3                     203
#define IDS_COMBO_4                     204
#define IDS_COMBO_5                     205
#define IDS_COMBO_6                     206
#define IDD_ABOUTBOX_3_1                301
#define IDS_REG_PARAMS_KEY_3_2          301
#define IDD_ABOUTBOX_3_2                302
#define IDS_REG_PARAMS_KEY_4_0          302
#define IDD_ABOUTBOX_4_0                302
#define IDD_ABOUTBOX_3_3                303
#define IDD_ABOUTBOX_3_4                304
#define IDD_ABOUTBOX_3_5                305
#define IDD_ABOUTBOX_3_6                306
#define IDD_ABOUTBOX_3_7                307
#define IDD_ABOUTBOX_3_8                308
#define IDS_MSG_USAGE_3_1               1301
#define IDS_MSG_USAGE_3_2               1302
#define IDS_MSG_USAGE_3_3               1303
#define IDS_MSG_USAGE_4_0               1303
#define IDS_MSG_USAGE_3_4               1304
#define IDS_MSG_USAGE_3_5               1305
#define IDS_MSG_USAGE_3_6               1306
#define IDS_MSG_USAGE_3_7               1307
#define IDS_MSG_USAGE_3_8               1308
#define IDC_BUTTON_JAVA_EXEC            1501
#define IDC_CHECK1                      1505
#define IDC_CHECK_JAR                   1505
#define IDC_BUTTON_JEDIT_TARGET         1506
#define IDC_BUTTON_JEDIT_WORKINGDIR     1509
#define IDC_CHECK_BATCH                 1510
#define IDC_CHECK_LOG                   1511
#define IDC_BASE                        2000
#define IDC_EDIT_JAVA_EXEC              2000
#define IDC_COMBO_JAVA_OPTIONS          2001
#define IDC_EDIT_JEDIT_TARGET           2002
#define IDC_EDIT_JEDIT_OPTIONS          2003
#define IDC_EDIT_JEDIT_WORKING_DIR      2004
#define IDC_EDIT_CMDLINE                2005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1516
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
