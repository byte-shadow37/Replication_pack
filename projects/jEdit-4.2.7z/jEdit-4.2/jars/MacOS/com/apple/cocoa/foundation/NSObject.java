package com.apple.cocoa.foundation;

import java.io.Serializable;

public class NSObject implements Cloneable, NSKeyValueCoding, Serializable
{
}
