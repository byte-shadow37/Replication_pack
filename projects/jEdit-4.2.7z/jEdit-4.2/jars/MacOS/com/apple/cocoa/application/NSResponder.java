package com.apple.cocoa.application;

import com.apple.cocoa.foundation.NSCoding;
import com.apple.cocoa.foundation.NSObject;

public class NSResponder extends NSObject implements NSCoding
{
}
