import pandas as pd
import os
import time
from openai import AzureOpenAI

endpoint = os.getenv("ENDPOINT_URL", "azure_endpoint_url")
deployment = os.getenv("DEPLOYMENT_NAME", "gpt-4o")
subscription_key = os.getenv("AZURE_OPENAI_API_KEY", "api_key")


def get_clone_information(file):
    info = pd.read_csv(file)
    return info.to_dict(orient="records")


def class_to_path(project, source, package, cls):
    return os.path.join(project, source, *package.split("."), cls + '.java')


def read_java_file(file_path):
    """Reads the content of a Java file and returns it as a string."""
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            c = file.read()
        return c
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
        return None
    except Exception as e:
        print(f"Error reading file: {e}")
        return None

client = AzureOpenAI(
    azure_endpoint=endpoint,
    api_key=subscription_key,
    api_version="2024-05-01-preview",
)

file_data = get_clone_information("path/to/filtered_data_csv_file")
for item in file_data:
    file_path_1 = class_to_path("jfreechart-1.0.10", item["source folder 1"], item["package 1"], item["class 1"])
    content_1 = read_java_file(file_path_1)
    file_path_2 = class_to_path("jfreechart-1.0.10", item["source folder 2"], item["package 2"], item["class 2"])
    content_2 = read_java_file(file_path_2)

    chat_history = [
        {
            "role": "system",
            "content": "You are a Java developer with expertise in code clone detection and refactoring."
        },
        {
            "role": "user",
            "content":
                "Here are the definitions of clone types:\n"
                "Type-1: Identical except for whitespace, comments, layout\n"
                "Type-2: Identical except for variable names, literals, types\n"
                "Type-3: Mostly similar but with some different statements\n"
                "Type-4: Different structure but same functionality\n"
                f"Now I have two code snippets, one is in method {item['Method 1']} with start line {item['Start Line 1']} and end line {item['End Line 1']} of following java class:\n"
                f"{content_1}"
                "\n"
                f"Another one is in method {item['Method 2']} with start line  {item['Start Line 2']} and end line {item['End Line 2']} of following java class:\n"
                f"{content_2}"
                "\n"
                "With no explanation, directly print these two code snippets, also indicate what types of clones are in these two code snippets."
        }
    ]
    try:
        clone_completion = client.chat.completions.create(
            model=deployment,
            messages=chat_history,
            temperature=0
        )
        item['clone_result'] = clone_completion.choices[0].message.content
        chat_history.append({"role": "assistant", "content": clone_completion.choices[0].message.content})
    except Exception as e:
        item['clone_result'] = f"GPT error: {e}"
    time.sleep(15)

    chat_history.append(
        {
            "role": "user",
            "content":
            "Refactor the clones in the given two code snippets by extracting the "
            "clones into a single method"
            "Ensure that there are no compilation errors and the functionality remains unchanged.\n\n"
            "- Since the clones exists in different files, extracted method will be written into their common superclass.\n"
            "- Ensure that instance-specific variables (e.g., `this.x`) are passed as parameters to the extracted method to maintain functionality.\n"
            "- Provide both:\n"
            "  1. The extracted method.\n"
            "  2. The method calls that should replace the clones in the original files.\n\n"
            "Do not include any explanations, only provide the refactored code."
        }
    )

    try:
        refactoring_completion = client.chat.completions.create(
            model="gpt-4o",
            messages=chat_history,
            temperature=0
        )
        item['refactoring_result'] = refactoring_completion.choices[0].message.content
        print(item['refactoring_result'])
    except Exception as e:
        item['refactoring_result'] = f"GPT error: {e}"

df = pd.DataFrame(file_data)
df.to_csv("path/to/output.csv", index=False)
