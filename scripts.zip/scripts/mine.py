import pandas as pd
from itertools import combinations
from bs4 import BeautifulSoup


def generate_id(df):
    df['Clone Group Index'] = df.groupby('Clone Group ID').cumcount() + 1


def generate_ordered_pair_id(df):
    pair_details = []

    for clone_group, group_data in df.groupby('Clone Group ID'):
        seq_ids = sorted(group_data['Clone Group Index'].tolist())
        pair_combinations = combinations(seq_ids, 2)

        for a, b in pair_combinations:
            pair_id = f"{clone_group}-{a}-{b}"
            row1 = group_data[group_data['Clone Group Index'] == a].iloc[0]
            row2 = group_data[group_data['Clone Group Index'] == b].iloc[0]
            pair_details.append({
                "Pair ID": pair_id,
                "Source Folder 1": row1["Source Folder"],
                "Package 1": row1["Package"],
                "Class 1": row1["Class"],
                "Method 1": row1["Method"],
                "Start Line 1": row1["Start Line"],
                "End Line 1": row1["End Line"],
                "Source Folder 2": row2["Source Folder"],
                "Package 2": row2["Package"],
                "Class 2": row2["Class"],
                "Method 2": row2["Method"],
                "Start Line 2": row2["Start Line"],
                "End Line 2": row2["End Line"],
            })

    return pair_details


def extract_mapped_statements_proper_format(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            soup = BeautifulSoup(file, 'html.parser')
    except FileNotFoundError:
        return [["", "", "html report missing"]]

    mapped_code_data = []

    try:
        mapping_summaries = soup.find_all('div', {'id': 'mappingsummarycenterer'})
    except:
        return [["", "", "Not found"]]

    if not mapping_summaries:
        return [["", "", "No mapped statements"]]

    for summary in mapping_summaries:
        clone_type_element = summary.find('td', string='Clone type')
        clone_type_value = clone_type_element.find_next_sibling('td').get_text(strip=True) if clone_type_element else 'Unknown'

        mapped_statements_table = summary.find_next('table', {'id': 'mappedstatements'})
        if mapped_statements_table:
            left_code_lines, right_code_lines = [], []

            rows = mapped_statements_table.find_all('tr', {'class': 'child'})
            for row in rows:
                cells = row.find_all('td', {'class': 'codeline'})
                if len(cells) == 2:
                    left_code_lines.append(cells[0].get_text(strip=True, separator=' '))
                    right_code_lines.append(cells[1].get_text(strip=True, separator=' '))

            left_code_combined = "\n".join(left_code_lines)
            right_code_combined = "\n".join(right_code_lines)

            mapped_code_data.append([left_code_combined, right_code_combined, clone_type_value])

    return mapped_code_data if mapped_code_data else [["", "", "No mapped statements"]]


if __name__ == "__main__":
    projects = ['apache', 'columba', 'emf', 'jmeter', 'jedit', 'jfreechart', 'jruby', 'hibernate', 'squirrel']

    for project in projects:
        print(f"Processing project: {project}")

        df = pd.read_csv('path_to_deckard_analyzed_file')
        df = df.loc[:, ~df.columns.str.contains('^Unnamed')]

        generate_id(df)
        df['Clone Group ID'] = df['Clone Group ID'].astype(int)
        df = df[~df['Source Folder'].str.contains('test', na=False)]

        generated_pairs = generate_ordered_pair_id(df.sort_values('Clone Group ID'))
        pairs_df = pd.DataFrame(generated_pairs)

        pairs_df['Pair ID'] = pairs_df['Pair ID'].apply(lambda x: tuple(map(int, x.split('-'))))
        pairs_df = pairs_df.sort_values(by='Pair ID')
        pairs_df['Pair ID'] = pairs_df['Pair ID'].apply(lambda x: '-'.join(map(str, x)))

        pair_ids = pairs_df['Pair ID']
        expanded_pairs = []

        for id in pair_ids:

            file_path = f'/path/to/html_reports_folder/{project}/{id}.htm'
            mapped_statements = extract_mapped_statements_proper_format(file_path)
            for left_code, right_code, clone_type in mapped_statements:
                expanded_pairs.append({
                    "Pair ID": id,
                    "Left Code": left_code,
                    "Right Code": right_code,
                    "Clone Type": clone_type
                })

        # Create a DataFrame for mapped statements
        mapped_df = pd.DataFrame(expanded_pairs)

        # Merge mapped statements with the original pairs DataFrame
        final_df = pd.merge(pairs_df, mapped_df, on="Pair ID", how="left")
        final_df = final_df[final_df['Clone Type'] != 'No mapped statements']
        # Save to CSV file
        final_df.to_csv(f'{project}_info.csv', index=False)
        print(f"Saved: {project}_info.csv")